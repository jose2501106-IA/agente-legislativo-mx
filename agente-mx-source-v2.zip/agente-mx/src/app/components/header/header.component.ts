import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Legislatura } from '../legislature-selector/legislature-selector.component';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  @Input() isDark = true;
  @Input() sidebarCollapsed = false;
  @Input() legislatura: Legislatura | null = null;
  @Output() toggleTheme = new EventEmitter<void>();
  @Output() changeLegislatura = new EventEmitter<void>();

  voteCount = 0;

  ngOnInit() {
    const target = this.legislatura?.votaciones ?? 10234;
    this.animateCounter(target, 1400);
  }

  ngOnChanges() {
    if (this.legislatura) {
      this.voteCount = 0;
      this.animateCounter(this.legislatura.votaciones, 1000);
    }
  }

  animateCounter(target: number, duration: number) {
    const start = Date.now();
    const tick = () => {
      const progress = Math.min((Date.now() - start) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      this.voteCount = Math.floor(target * ease);
      if (progress < 1) requestAnimationFrame(tick);
      else this.voteCount = target;
    };
    requestAnimationFrame(tick);
  }

  formatNumber(n: number): string { return n.toLocaleString('es-MX'); }
}
