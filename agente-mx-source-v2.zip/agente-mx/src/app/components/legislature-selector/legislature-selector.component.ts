import { Component, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface Legislatura {
  id: string;
  romano: string;
  periodo: string;
  anios: string;
  inicio: number;
  fin: number | null;
  estado: 'completa' | 'en_curso' | 'historica';
  descripcion: string;
  disponible: boolean;
  votaciones: number;
  diputados: number;
  colorTop: string;
  nota?: string;
}

@Component({
  selector: 'app-legislature-selector',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './legislature-selector.component.html',
  styleUrls: ['./legislature-selector.component.scss']
})
export class LegislatureSelectorComponent {
  @Output() legislaturaSelected = new EventEmitter<Legislatura>();

  legislaturas: Legislatura[] = [
    {
      id: 'lxvi',
      romano: 'LXVI',
      periodo: 'Legislatura actual',
      anios: '2024–2027',
      inicio: 2024, fin: null,
      estado: 'en_curso',
      descripcion: 'En funciones desde septiembre 2024. Datos parciales disponibles y actualizándose continuamente.',
      disponible: true,
      votaciones: 312,
      diputados: 500,
      colorTop: '#B8932F',
      nota: 'Datos hasta marzo 2026'
    },
    {
      id: 'lxv',
      romano: 'LXV',
      periodo: 'Legislatura',
      anios: '2021–2024',
      inicio: 2021, fin: 2024,
      estado: 'completa',
      descripcion: 'Datos completos. Incluye análisis de disciplina partidista, radar electoral y detector de contradicciones.',
      disponible: true,
      votaciones: 10234,
      diputados: 500,
      colorTop: '#2E7D4F'
    },
    {
      id: 'lxiv',
      romano: 'LXIV',
      periodo: 'Legislatura',
      anios: '2018–2021',
      inicio: 2018, fin: 2021,
      estado: 'historica',
      descripcion: 'Primera legislatura con mayoría de Morena tras las elecciones de 2018. Análisis histórico disponible próximamente.',
      disponible: false,
      votaciones: 8940,
      diputados: 500,
      colorTop: '#546A82'
    },
    {
      id: 'lxiii',
      romano: 'LXIII',
      periodo: 'Legislatura',
      anios: '2015–2018',
      inicio: 2015, fin: 2018,
      estado: 'historica',
      descripcion: 'Legislatura caracterizada por el dominio del PRI y alianzas del Pacto por México. Próximamente disponible.',
      disponible: false,
      votaciones: 7820,
      diputados: 500,
      colorTop: '#546A82'
    }
  ];

  seleccionar(leg: Legislatura) {
    if (!leg.disponible) return;
    this.legislaturaSelected.emit(leg);
  }

  formatNum(n: number): string {
    return n.toLocaleString('es-MX');
  }
}
