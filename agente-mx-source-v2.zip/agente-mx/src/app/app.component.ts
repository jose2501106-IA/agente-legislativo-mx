import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { ChatComponent } from './views/chat/chat.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { DiputadosComponent } from './views/diputados/diputados.component';
import { MetodologiaComponent } from './views/metodologia/metodologia.component';
import { LegislatureSelectorComponent, Legislatura } from './components/legislature-selector/legislature-selector.component';
import { ChatService } from './services/chat.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    HeaderComponent,
    SidebarComponent,
    ChatComponent,
    DashboardComponent,
    DiputadosComponent,
    MetodologiaComponent,
    LegislatureSelectorComponent
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  activeView = 'chat';
  sidebarCollapsed = false;
  isDark = true;
  legislaturaActual: Legislatura | null = null;
  showSelector = true;

  constructor(public chatService: ChatService) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }

  onLegislaturaSelected(leg: Legislatura) {
    this.legislaturaActual = leg;
    this.showSelector = false;
    this.chatService.showToast(
      'success',
      `${leg.romano} Legislatura cargada`,
      `${leg.anios} · ${leg.votaciones.toLocaleString('es-MX')} votaciones`
    );
  }

  cambiarLegislatura() {
    this.showSelector = true;
    this.legislaturaActual = null;
    this.activeView = 'chat';
    this.chatService.clearMessages();
  }

  setView(view: string) { this.activeView = view; }
  toggleSidebar() { this.sidebarCollapsed = !this.sidebarCollapsed; }
  toggleTheme() {
    this.isDark = !this.isDark;
    document.documentElement.setAttribute('data-theme', this.isDark ? 'dark' : 'light');
  }
}
