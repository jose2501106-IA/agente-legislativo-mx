import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LegislaturaService, Legislatura } from '../../services/legislatura.service';

@Component({
  selector: 'app-selector',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './selector.component.html',
  styleUrls: ['./selector.component.scss']
})
export class SelectorComponent {
  hoveredId: string | null = null;

  constructor(public legService: LegislaturaService) {}

  seleccionar(leg: Legislatura) {
    if (!leg.disponible) return;
    this.legService.seleccionar(leg);
  }

  formatNumber(n: number): string {
    return n.toLocaleString('es-MX');
  }
}
