import { Injectable } from '@angular/core';

export interface Legislatura {
  id: string;
  numero: string;
  periodo: string;
  anios: string;
  estado: 'completa' | 'en_curso' | 'historica';
  descripcion: string;
  disponible: boolean;
  votaciones: number;
  diputados: number;
}

@Injectable({ providedIn: 'root' })
export class LegislaturaService {
  private _seleccionada: Legislatura | null = null;

  legislaturas: Legislatura[] = [
    {
      id: 'lxvi', numero: 'LXVI', periodo: 'Legislatura', anios: '2024-2027',
      estado: 'en_curso',
      descripcion: 'Legislatura actual en funciones. Datos parciales disponibles conforme avanza el periodo.',
      disponible: true, votaciones: 312, diputados: 500
    },
    {
      id: 'lxv', numero: 'LXV', periodo: 'Legislatura', anios: '2021-2024',
      estado: 'completa',
      descripcion: 'Datos completos. Incluye analisis de disciplina partidista, radar electoral y detector de contradicciones.',
      disponible: true, votaciones: 10234, diputados: 500
    },
    {
      id: 'lxiv', numero: 'LXIV', periodo: 'Legislatura', anios: '2018-2021',
      estado: 'historica',
      descripcion: 'Primera legislatura con mayoria de Morena tras las elecciones de 2018. Datos en proceso de integracion.',
      disponible: false, votaciones: 8940, diputados: 500
    },
    {
      id: 'lxiii', numero: 'LXIII', periodo: 'Legislatura', anios: '2015-2018',
      estado: 'historica',
      descripcion: 'Legislatura caracterizada por el dominio del PRI y sus alianzas parlamentarias. Datos en proceso.',
      disponible: false, votaciones: 7820, diputados: 500
    }
  ];

  get seleccionada(): Legislatura | null { return this._seleccionada; }
  get yaSeleccionada(): boolean { return this._seleccionada !== null; }

  seleccionar(leg: Legislatura | null) { this._seleccionada = leg; }

  getEtiqueta(estado: string): string {
    const map: Record<string, string> = {
      completa: 'Datos completos', en_curso: 'En curso', historica: 'Datos historicos'
    };
    return map[estado] || '';
  }
}
