import { Component, ViewChild, ElementRef, AfterViewChecked } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ChatService } from '../../services/chat.service';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements AfterViewChecked {
  @ViewChild('messagesEl') messagesEl!: ElementRef;
  @ViewChild('inputEl') inputEl!: ElementRef;

  inputText = '';
  isLoading = false;
  loaderText = '';
  private loaderInterval: any;
  private scrollBottom = false;

  useCases = [
    { icon: '⚖️', audience: 'Para abogados', title: 'Antecedentes legislativos con fuente oficial', desc: 'Verifica el historial de votaciones para sustentar argumentos jurídicos.', query: '¿Cuál es el historial de votaciones y disciplina del partido PAN?' },
    { icon: '🏛️', audience: 'Para legisladores', title: 'Historial de disciplina de bancada', desc: 'Consulta la cohesión interna de cualquier partido y detecta disidentes.', query: '¿Cuál es el índice de disciplina de la bancada de Morena?' },
    { icon: '🔍', audience: 'Para asesores', title: 'Detector de contradicciones discurso-voto', desc: 'Analiza inconsistencias entre el discurso político y el voto real.', query: '¿Hay contradicciones entre las iniciativas y los votos del PRI?' },
  ];

  constructor(public chatService: ChatService) {}

  ngAfterViewChecked() {
    if (this.scrollBottom && this.messagesEl) {
      const el = this.messagesEl.nativeElement;
      el.scrollTop = el.scrollHeight;
      this.scrollBottom = false;
    }
  }

  get hasMessages() { return this.chatService.messages.length > 0; }

  fillInput(query: string) { this.inputText = query; this.inputEl?.nativeElement?.focus(); }

  async send() {
    const text = this.inputText.trim();
    if (!text || this.isLoading) return;
    this.inputText = '';
    this.chatService.addUserMessage(text);
    this.scrollBottom = true;
    this.isLoading = true;
    this.startLoader();
    await this.chatService.simulateResponse();
    this.stopLoader();
    this.isLoading = false;
    this.scrollBottom = true;
  }

  onKeydown(e: KeyboardEvent) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); this.send(); } }

  startLoader() {
    const texts = this.chatService.getLoaderTexts();
    let i = 0;
    this.loaderText = texts[0];
    this.loaderInterval = setInterval(() => { i = (i+1) % texts.length; this.loaderText = texts[i]; }, 1800);
  }

  stopLoader() { clearInterval(this.loaderInterval); this.loaderText = ''; }

  toggleSources(msg: any) { this.chatService.toggleSources(msg); }
}
