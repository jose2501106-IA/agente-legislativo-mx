import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-metodologia', standalone: true, imports: [CommonModule],
  templateUrl: './metodologia.component.html', styleUrls: ['./metodologia.component.scss']
})
export class MetodologiaComponent {
  limitaciones = [
    'Cobertura temporal: El análisis abarca las votaciones nominales registradas en el sistema SITL de la Cámara de Diputados para la LXV Legislatura (2021–2024). Votaciones por cédula o cómputo no están incluidas.',
    'Naturaleza del índice: El IDP no distingue entre ausencias justificadas e injustificadas. Una ausencia en votación crítica tiene el mismo peso que una ausencia en votación de trámite.',
    'Determinación de línea oficial: Se usa el voto mayoritario de la fracción como proxy de la posición institucional del partido. En votaciones con distribución uniforme, el resultado puede ser sensible a pequeñas variaciones.',
    'Inferencia causal: Los patrones detectados en el Radar Electoral son correlacionales. AgenteMX no establece causalidad entre comportamiento electoral y ciclo político.'
  ];
}
