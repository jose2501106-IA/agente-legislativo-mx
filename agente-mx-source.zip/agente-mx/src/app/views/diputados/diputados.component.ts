import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { DataService, Diputado } from '../../services/data.service';

@Component({
  selector: 'app-diputados',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './diputados.component.html',
  styleUrls: ['./diputados.component.scss']
})
export class DiputadosComponent implements OnInit {
  all: Diputado[] = [];
  filtered: Diputado[] = [];
  paged: Diputado[] = [];
  searchText = '';
  partyFilter = '';
  sortBy = 'disciplina';
  currentPage = 1;
  rowsPerPage = 12;
  totalPages = 1;
  parties = ['Morena','PAN','PRI','PRD','PT','PVEM','MC'];

  constructor(public data: DataService) {}

  ngOnInit() { this.all = this.data.getDiputados(); this.applyFilters(); }

  applyFilters() {
    let r = [...this.all];
    if (this.searchText) r = r.filter(d => d.nombre.toLowerCase().includes(this.searchText.toLowerCase()));
    if (this.partyFilter) r = r.filter(d => d.partido === this.partyFilter);
    if (this.sortBy === 'disciplina') r.sort((a,b) => b.disciplina - a.disciplina);
    else if (this.sortBy === 'ausencias') r.sort((a,b) => a.asistencia - b.asistencia);
    else r.sort((a,b) => a.nombre.localeCompare(b.nombre));
    this.filtered = r;
    this.totalPages = Math.ceil(r.length / this.rowsPerPage);
    this.currentPage = 1;
    this.updatePage();
  }

  updatePage() {
    const s = (this.currentPage-1)*this.rowsPerPage;
    this.paged = this.filtered.slice(s, s+this.rowsPerPage);
  }

  goPage(p: number) {
    if (p < 1 || p > this.totalPages) return;
    this.currentPage = p;
    this.updatePage();
  }

  get pages() { return Array.from({length: this.totalPages}, (_,i) => i+1); }
}
