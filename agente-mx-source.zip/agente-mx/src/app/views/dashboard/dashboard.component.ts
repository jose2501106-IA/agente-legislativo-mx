import { Component, OnInit, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DataService } from '../../services/data.service';
import { Chart, registerables } from 'chart.js';
Chart.register(...registerables);

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements AfterViewInit {
  hallazgos: any[] = [];
  constructor(private data: DataService) {}
  ngOnInit() { this.hallazgos = this.data.getHallazgos(); }
  ngAfterViewInit() { setTimeout(() => this.initCharts(), 100); }

  initCharts() {
    const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
    const gridColor = isDark ? '#1F3050' : '#E2E6EC';
    const textColor = isDark ? '#8A9BB0' : '#5A6A7A';
    Chart.defaults.font.family = "'JetBrains Mono', monospace";
    Chart.defaults.color = textColor;

    const d = this.data.getDisciplinaData();
    new Chart('disciplinaChart', {
      type: 'bar',
      data: { labels: d.labels, datasets: [{ label: 'Disciplina %', data: d.values, backgroundColor: d.colors, borderColor: d.borders, borderWidth: 1, borderRadius: 3 }] },
      options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: '#162030', borderColor: '#2A3F5F', borderWidth: 1, callbacks: { label: (c: any) => `  Disciplina: ${c.raw}%` } } },
        scales: { x: { min: 97, max: 101, grid: { color: gridColor }, ticks: { callback: (v: any) => v+'%', font: { size: 11 } } }, y: { grid: { display: false }, ticks: { font: { size: 11 } } } }
      }
    });

    const v = this.data.getVotosData();
    new Chart('votosChart', {
      type: 'bar',
      data: { labels: v.labels, datasets: [
        { label: 'A favor', data: v.favor, backgroundColor: 'rgba(46,125,79,0.75)' },
        { label: 'En contra', data: v.contra, backgroundColor: 'rgba(192,57,43,0.65)' },
        { label: 'Ausente', data: v.ausente, backgroundColor: 'rgba(90,106,122,0.4)' }
      ]},
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 16, usePointStyle: true } }, tooltip: { backgroundColor: '#162030', borderColor: '#2A3F5F', borderWidth: 1 } },
        scales: { x: { stacked: true, grid: { display: false }, ticks: { font: { size: 11 } } }, y: { stacked: true, grid: { color: gridColor }, ticks: { callback: (v: any) => v+'%', font: { size: 11 } } } }
      }
    });

    const r = this.data.getRadarData();
    new Chart('radarChart', {
      type: 'bar',
      data: { labels: r.labels, datasets: [
        { label: 'Período normal', data: r.normal, backgroundColor: 'rgba(36,74,124,0.65)', borderColor: '#244A7C', borderWidth: 1, borderRadius: 3 },
        { label: 'Período electoral', data: r.electoral, backgroundColor: 'rgba(184,147,47,0.55)', borderColor: '#B8932F', borderWidth: 1, borderRadius: 3 }
      ]},
      options: { responsive: true, maintainAspectRatio: false,
        plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, padding: 16, usePointStyle: true } }, tooltip: { backgroundColor: '#162030', borderColor: '#2A3F5F', borderWidth: 1 } },
        scales: { x: { grid: { display: false }, ticks: { font: { size: 11 } } }, y: { grid: { color: gridColor }, ticks: { callback: (v: any) => v+'%', font: { size: 11 } }, title: { display: true, text: 'Tasa de ausencias %', font: { size: 10 } } } }
      }
    });
  }
}
