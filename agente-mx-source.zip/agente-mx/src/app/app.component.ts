import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { ChatComponent } from './views/chat/chat.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { DiputadosComponent } from './views/diputados/diputados.component';
import { MetodologiaComponent } from './views/metodologia/metodologia.component';
import { ChatService } from './services/chat.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, HeaderComponent, SidebarComponent, ChatComponent, DashboardComponent, DiputadosComponent, MetodologiaComponent],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  activeView = 'chat';
  sidebarCollapsed = false;
  isDark = true;
  constructor(public chatService: ChatService) {
    document.documentElement.setAttribute('data-theme','dark');
  }
  setView(view: string) { this.activeView = view; }
  toggleSidebar() { this.sidebarCollapsed = !this.sidebarCollapsed; }
  toggleTheme() {
    this.isDark = !this.isDark;
    document.documentElement.setAttribute('data-theme', this.isDark ? 'dark' : 'light');
  }
}
