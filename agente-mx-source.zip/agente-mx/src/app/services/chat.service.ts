import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

export interface Message {
  id: string; role: 'user'|'agent'; text: string;
  tools?: string[]; sources?: {url:string;label:string}[];
  sourcesOpen?: boolean;
}

export interface Toast {
  id: string; type: 'success'|'error'|'info'; title: string; msg: string;
}

@Injectable({ providedIn: 'root' })
export class ChatService {
  messages: Message[] = [];
  toasts: Toast[] = [];
  toastSubject = new Subject<Toast>();

  private loaderTexts = [
    'Consultando registro oficial de votaciones...',
    'Procesando 10,234 registros legislativos...',
    'Verificando fuentes en sitl.diputados.gob.mx...',
    'Generando análisis con modelo de lenguaje...',
    'Aplicando índice de disciplina partidista...'
  ];

  private sampleResponses = [
    {
      text: `El partido <strong>PAN</strong> registra un índice de disciplina promedio de <strong>99.9%</strong> en la LXV Legislatura.<sup><a href="https://www.diputados.gob.mx/Votaciones.htm" target="_blank">[1]</a></sup><br><br>· 16 de 16 diputados clasificados como "Muy disciplinados" (≥90%)<sup><a href="https://datos.gob.mx/busca/dataset/camara-de-diputados" target="_blank">[2]</a></sup><br>· Menor disciplina: Olga Luz Espinosa Morales con 98.6%<br>· 0 diputados en categoría "Disidente" (&lt;70%)<sup><a href="https://www.diputados.gob.mx" target="_blank">[3]</a></sup>`,
      tools: ['calcular_disciplina_partido'],
      sources: [
        {url:'https://www.diputados.gob.mx/Votaciones.htm',label:'Votaciones nominales — PAN · Cámara de Diputados'},
        {url:'https://datos.gob.mx/busca/dataset/camara-de-diputados',label:'datos.gob.mx — Dataset abierto'},
        {url:'https://www.diputados.gob.mx',label:'Cámara de Diputados — Portal oficial'}
      ]
    },
    {
      text: `<strong>Morena</strong> en la LXV Legislatura:<sup><a href="https://www.diputados.gob.mx/Votaciones.htm" target="_blank">[1]</a></sup><br><br><strong>Distribución de votos:</strong><br>· A favor: 5,920 (76.1%)<br>· En contra: 1,850 (23.8%)<sup><a href="https://datos.gob.mx/busca/dataset/camara-de-diputados" target="_blank">[2]</a></sup><br>· Ausentes: 371<br><br><strong>Top ausencias:</strong><br>1. Villarreal García Ricardo — 16<br>2. García García José Antonio — 11<br>3. Romo Cuéllar Martha Estela — 10<sup><a href="https://www.diputados.gob.mx" target="_blank">[3]</a></sup>`,
      tools: ['resumen_por_partido'],
      sources: [
        {url:'https://www.diputados.gob.mx/Votaciones.htm',label:'Votaciones nominales — Morena · Cámara de Diputados'},
        {url:'https://datos.gob.mx/busca/dataset/camara-de-diputados',label:'datos.gob.mx — Dataset abierto'},
        {url:'https://www.diputados.gob.mx',label:'Cámara de Diputados — Portal oficial'}
      ]
    },
    {
      text: `<strong>Radar Electoral — Morena:</strong><sup><a href="https://www.diputados.gob.mx/Votaciones.htm" target="_blank">[1]</a></sup><br><br>· Período normal: 4.4% ausencias · 70% votos a favor<br>· Período electoral: 0.0% ausencias · Reducción de <strong>-4.4%</strong><sup><a href="https://www.ine.mx/voto-y-elecciones/elecciones-2024/" target="_blank">[2]</a></sup><br><br><em>Interpretación:</em> El partido reduce significativamente sus ausencias en año electoral, sugiriendo una estrategia deliberada de mayor visibilidad legislativa ante los comicios de junio 2024.<sup><a href="https://datos.gob.mx/busca/dataset/camara-de-diputados" target="_blank">[3]</a></sup>`,
      tools: ['radar_electoral_partido'],
      sources: [
        {url:'https://www.diputados.gob.mx/Votaciones.htm',label:'Votaciones nominales — Morena · Cámara de Diputados'},
        {url:'https://www.ine.mx/voto-y-elecciones/elecciones-2024/',label:'INE — Elecciones Federales 2024'},
        {url:'https://datos.gob.mx/busca/dataset/camara-de-diputados',label:'datos.gob.mx — Dataset abierto'}
      ]
    }
  ];

  private responseIndex = 0;
  currentLoaderText = this.loaderTexts[0];
  private loaderInterval: any;

  getLoaderTexts() { return this.loaderTexts; }

  addUserMessage(text: string): string {
    const id = 'msg-' + Date.now();
    this.messages.push({ id, role: 'user', text });
    return id;
  }

  async simulateResponse(): Promise<void> {
    return new Promise(resolve => {
      setTimeout(() => {
        const r = this.sampleResponses[this.responseIndex % this.sampleResponses.length];
        this.responseIndex++;
        const id = 'msg-' + Date.now();
        this.messages.push({ id, role: 'agent', text: r.text, tools: r.tools, sources: r.sources, sourcesOpen: false });
        this.showToast('success', 'Análisis completado', r.tools.join(', ') + ' · Fuentes verificadas');
        resolve();
      }, 2800 + Math.random() * 1200);
    });
  }

  showToast(type: 'success'|'error'|'info', title: string, msg: string) {
    const t: Toast = { id: 'toast-' + Date.now(), type, title, msg };
    this.toasts.push(t);
    setTimeout(() => { this.toasts = this.toasts.filter(x => x.id !== t.id); }, 4500);
  }

  toggleSources(msg: Message) { msg.sourcesOpen = !msg.sourcesOpen; }
  clearMessages() { this.messages = []; this.responseIndex = 0; }
}
