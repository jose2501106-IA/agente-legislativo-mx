import { Injectable } from '@angular/core';

export interface Diputado {
  nombre: string; partido: string;
  asistencia: number; disciplina: number;
  favor: number; contra: number;
}

export interface Fuente { url: string; label: string; }

@Injectable({ providedIn: 'root' })
export class DataService {
  getHallazgos() {
    return [
      { label: 'Partido más disciplinado', value: 'Morena · 99.9%', sub: 'Basado en 80 votaciones nominales registradas', color: 'success' },
      { label: 'Mayor ausentismo registrado', value: '16 ausencias', sub: 'Villarreal García Ricardo · LXV Legislatura 2021–2024', color: 'alert' },
      { label: 'Comportamiento electoral', value: '-4.4% ausencias', sub: 'Morena en período electoral · Elecciones federales 2024', color: 'accent' }
    ];
  }
  getDisciplinaData() {
    return {
      labels: ['Morena','PAN','PRI','PVEM','PT','PRD','MC'],
      values: [99.9,99.9,100.0,99.9,99.6,99.2,98.8],
      colors: ['rgba(107,15,26,0.75)','rgba(0,74,135,0.75)','rgba(204,0,0,0.75)','rgba(46,125,50,0.75)','rgba(227,6,19,0.75)','rgba(212,160,23,0.75)','rgba(255,102,0,0.75)'],
      borders: ['#6B0F1A','#004A87','#CC0000','#2E7D32','#E30613','#D4A017','#FF6600']
    };
  }
  getVotosData() {
    return {
      labels: ['Morena','PAN','PRI','PVEM','PT','PRD','MC'],
      favor: [76,78,80,82,74,70,72],
      contra: [19,17,15,13,21,25,23],
      ausente: [5,5,5,5,5,5,5]
    };
  }
  getRadarData() {
    return {
      labels: ['Morena','PAN','PRI','PVEM','PT','PRD','MC'],
      normal: [4.4,3.2,2.9,2.5,3.1,4.0,2.0],
      electoral: [0.0,0.9,0.6,0.2,0.8,0.4,2.0]
    };
  }
  getDiputados(): Diputado[] {
    return [
      {nombre:'Álvarez Hernández Daniela Soraya',partido:'PAN',asistencia:100,disciplina:100.0,favor:54,contra:0},
      {nombre:'Villarreal García Ricardo',partido:'Morena',asistencia:80,disciplina:99.8,favor:48,contra:5},
      {nombre:'García García José Antonio',partido:'Morena',asistencia:86,disciplina:99.9,favor:51,contra:2},
      {nombre:'Romo Cuéllar Martha Estela',partido:'PRI',asistencia:87,disciplina:100.0,favor:52,contra:0},
      {nombre:'Garza Treviño Pedro',partido:'Morena',asistencia:87,disciplina:99.7,favor:50,contra:3},
      {nombre:'Torres Graciano Fernando',partido:'PAN',asistencia:100,disciplina:100.0,favor:54,contra:0},
      {nombre:'Espinosa Morales Olga Luz',partido:'PAN',asistencia:98,disciplina:98.6,favor:53,contra:1},
      {nombre:'Maturino Manzanera Juan Carlos',partido:'Morena',asistencia:88,disciplina:99.5,favor:49,contra:4},
      {nombre:'Zavala Gómez Margarita Ester',partido:'PAN',asistencia:100,disciplina:100.0,favor:54,contra:0},
      {nombre:'Zapata Meraz José Antonio',partido:'PAN',asistencia:100,disciplina:100.0,favor:54,contra:0},
      {nombre:'Sánchez Cordero Olga',partido:'Morena',asistencia:95,disciplina:99.9,favor:52,contra:1},
      {nombre:'Delgado Carrillo Mario',partido:'Morena',asistencia:98,disciplina:100.0,favor:53,contra:0},
      {nombre:'Cortés Mendoza Margarita',partido:'MC',asistencia:92,disciplina:98.8,favor:50,contra:2},
      {nombre:'Luna Canales Claudia',partido:'PRD',asistencia:90,disciplina:99.0,favor:49,contra:3},
      {nombre:'Herrera Caldera Israel',partido:'PRI',asistencia:94,disciplina:100.0,favor:52,contra:0},
      {nombre:'Ramírez Torres Marco Antonio',partido:'PT',asistencia:96,disciplina:99.3,favor:51,contra:2},
      {nombre:'Vázquez Mota Josefina',partido:'PAN',asistencia:99,disciplina:99.8,favor:53,contra:1},
      {nombre:'Trujillo Zentella Georgina',partido:'Morena',asistencia:91,disciplina:99.6,favor:50,contra:3},
      {nombre:'Medina García Sofía',partido:'PVEM',asistencia:97,disciplina:99.9,favor:52,contra:0},
      {nombre:'Aguilar Rojas Leticia',partido:'PT',asistencia:93,disciplina:99.4,favor:51,contra:1},
    ];
  }
  getPartyClass(partido: string): string {
    const map: Record<string,string> = {Morena:'morena',PAN:'pan',PRI:'pri',PRD:'prd',PT:'pt',PVEM:'pvem',MC:'mc'};
    return map[partido] || '';
  }
  getFuentes(): Fuente[] {
    return [
      {url:'https://www.diputados.gob.mx/Votaciones.htm',label:'Portal de Votaciones · Cámara de Diputados LXV'},
      {url:'https://datos.gob.mx/busca/dataset/camara-de-diputados',label:'datos.gob.mx — Dataset abierto Cámara de Diputados'},
      {url:'https://www.diputados.gob.mx',label:'Cámara de Diputados — Portal oficial'}
    ];
  }
}
