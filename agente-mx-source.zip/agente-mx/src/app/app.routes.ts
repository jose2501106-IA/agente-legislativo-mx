import { Routes } from '@angular/router';
import { ChatComponent } from './views/chat/chat.component';
import { DashboardComponent } from './views/dashboard/dashboard.component';
import { DiputadosComponent } from './views/diputados/diputados.component';
import { MetodologiaComponent } from './views/metodologia/metodologia.component';

export const routes: Routes = [
  { path: '', redirectTo: 'chat', pathMatch: 'full' },
  { path: 'chat', component: ChatComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'diputados', component: DiputadosComponent },
  { path: 'metodologia', component: MetodologiaComponent },
];
