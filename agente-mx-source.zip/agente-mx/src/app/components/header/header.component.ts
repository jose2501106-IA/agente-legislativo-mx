import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {
  @Input() isDark = true;
  @Input() sidebarCollapsed = false;
  @Output() toggleTheme = new EventEmitter<void>();
  voteCount = 0;
  ngOnInit() { this.animateCounter(10234, 1200); }
  animateCounter(target: number, duration: number) {
    const start = Date.now();
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      this.voteCount = Math.floor(target * progress);
      if (progress < 1) requestAnimationFrame(tick);
      else this.voteCount = target;
    };
    requestAnimationFrame(tick);
  }
  formatNumber(n: number): string { return n.toLocaleString('es-MX'); }
}
