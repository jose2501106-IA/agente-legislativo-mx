import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Input() collapsed = false;
  @Input() activeView = 'chat';
  @Output() viewChange = new EventEmitter<string>();
  @Output() toggleCollapse = new EventEmitter<void>();
  navItems = [
    { id: 'chat', label: 'Chat', icon: 'chat', section: 'Principal' },
    { id: 'dashboard', label: 'Dashboard', icon: 'grid', section: '' },
    { id: 'diputados', label: 'Diputados', icon: 'users', section: 'Análisis' },
    { id: 'metodologia', label: 'Metodología', icon: 'check', section: '' },
  ];
}
